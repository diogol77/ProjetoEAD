
#ifndef MEIO_H
#define MEIO_H

//Criação da struct do meio
typedef struct meio
{int codigo; // código do meio
 char tipo[50];
 float bateria;
 float autonomia;
 struct meio* seguinte;
} Meio;

//Criação da struct do cliente
typedef struct cliente_registo
{int codigo; // código do cliente
 char nome[50];
 char morada[50];
 float saldo;
 struct cliente_registo* seguinte;
} Cliente;

//Criação da struct do gestor
typedef struct gestor_registo
{int codigo; // código do gestor
 char nome[50];
 char morada[50];
 struct gestor_registo* seguinte;
} Gestor;


// Protótipos de funções
Meio* inserirMeio(Meio* inicio, int cod, char tipo[], float bat, float aut); // Inserção de um novo registo
void listarMeios(Meio* inicio); // listar na consola o conteúdo da lista ligada
int existeMeio(Meio* inicio, int codigo); // Determinar existência do 'codigo' na lista ligada 'inicio'
Meio* removerMeio(Meio* inicio, int cod); // Remover um meio a partir do seu código


int guardarMeios(Meio* inicio); //Refere  a guardar em txt os meios
Meio* lerMeios(); //Refere a ler na consola, o conteudo guardado em txt dos meios


int guardarGestor(Gestor* inicio); //Refere  a guardar em txt os gestores
Gestor *lerGestores();  // Refere a ler na consola, o conteudo guardado em txt dos gestores


int guardarClientes (Cliente *inicio); //Refere a guardarem txt os clientes
Cliente *lerClientes(); //Refere a ler na consola, o conteudo guardado em txt



#endif