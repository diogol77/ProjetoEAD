#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "meio.h"

// Inserção de um novo meio
Meio *inserirMeio(Meio *inicio, int cod, char tipo[], float bat, float aut)
{
  while (existeMeio(inicio, cod))
  {
    printf("O código %d já existe");
    
  }
  Meio *novo = malloc(sizeof(struct meio));
  if (novo != NULL)
  {
    novo->codigo = cod;
    strcpy(novo->tipo, tipo);
    novo->bateria = bat;
    novo->autonomia = aut;
    novo->seguinte = inicio;
    inicio = novo;
  }

  return inicio;
}

//////////////////////////CÓDIGO PARA GUARDAR EM TXT////////////////////////////////////////

//Codigo para guarder os meios em txt
int guardarMeios(Meio* inicio)
{FILE* fp;
 fp = fopen("meios.txt","w");
 if (fp!=NULL)
 {
 Meio* aux= inicio;
 while (aux != NULL)
 {
  fprintf(fp,"%d;%f;%f;%s\n", aux->codigo, aux->bateria, 
	                      aux->autonomia, aux->tipo);
  aux = aux->seguinte;
 }
 fclose(fp);
 return(1);
 }
 else return(0);
}

//////////Código para guardar Gestores em Txt
int guardarGestor(Gestor* inicio)
{
    FILE* fp;
    fp = fopen("gestores.txt", "w");
    if (fp != NULL)
    {
        Gestor* aux = inicio;
        while (aux != NULL)
        {
            fprintf(fp, "%d;%s;%s\n", aux->codigo, aux->nome, aux->morada);
            aux = aux->seguinte;
        }
        fclose(fp);
        return 1;
    }
    else
    {
        return 0;
    }
}

///// Codigo para guardar cliente em txt
int guardarClientes(Cliente* inicio)
{
    FILE* fp;
    fp = fopen("clientes.txt", "w");
    if (fp != NULL)
    {
        Cliente* aux = inicio;
        while (aux != NULL)
        {
            fprintf(fp, "%d;%s;%s;%f\n", aux->codigo, aux->nome, aux->morada, aux->saldo);
            aux = aux->seguinte;
        }
        fclose(fp);
        return 1;
    }
    else
    {
        return 0;
    }
}
//////////////////////////////////FIM DO GUARDAR EM TXT///////////////////////////////////

// Listar na consola os meios
void listarMeios(Meio *inicio)
{
  while (inicio != NULL)
  {
    printf("\n------------------------------------------------------------------------------------------------------------------\n");
    printf("\t Codigo do meio: %d       \tTipo de mobilidade: %s    \tNivel da bateria: %.1f%%    \tAutonomia: %.1fkm", inicio->codigo, inicio->tipo, inicio->bateria, inicio->autonomia);
    inicio = inicio->seguinte;
  }

}
//CÓDIGO PARA LER OS FICHEIROS EM TXT/////////////////////////////////////////

// Código para ler os meios na consola, existentes no txt
Meio *lerMeios()
{
  FILE *fp;
  int cod;
  float bat, aut;
  char tipo[50];
  Meio *aux = NULL;
  fp = fopen("meios.txt", "r");
  if (fp != NULL)
  {
    while (fscanf(fp, "%d;%f;%f;%s\n", &cod, &bat, &aut, tipo) == 4)
    {
      aux = inserirMeio(aux, cod, tipo, bat, aut);
    }
    fclose(fp);
  }
  return (aux);
}

//Código par ler os Gestores na consola existentes no txt
Gestor *lerGestores()
{
  FILE *fp;
  int codigo;
  char nome[50], morada[50];
  Gestor *head = NULL, *newGestor = NULL;
  fp = fopen("gestores.txt", "r");
  if (fp != NULL)
  {
    while (fscanf(fp, "%d;%49[^;];%49[^;\n]\n", &codigo, nome, morada) == 3)
    {
      newGestor = (Gestor *) malloc(sizeof(Gestor));
      newGestor->codigo = codigo;
      strcpy(newGestor->nome, nome);
      strcpy(newGestor->morada, morada);
      newGestor->seguinte = NULL;
      if (head == NULL)
      {
        head = newGestor;
      }
      else
      {
        Gestor *temp = head;
        while (temp->seguinte != NULL)
        {
          temp = temp->seguinte;
        }
        temp->seguinte = newGestor;
      }
    }
    fclose(fp);
  }
  return (head);
}

// codigo para ler na consola os clientes do txt
Cliente *lerClientes()
{
FILE *fp;
int codigo;
char nome[50], morada[50];
float saldo;
Cliente *head = NULL, *newCliente = NULL;
fp = fopen("clientes.txt", "r");
if (fp != NULL)
{
while (fscanf(fp, "%d;%49[^;];%49[^;];%f\n", &codigo, nome, morada, &saldo) == 4)
{
newCliente = (Cliente *) malloc(sizeof(Cliente));
newCliente->codigo = codigo;
strcpy(newCliente->nome, nome);
strcpy(newCliente->morada, morada);
newCliente->saldo = saldo;
newCliente->seguinte = NULL;
if (head == NULL)
{
head = newCliente;
}
else
{
Cliente *temp = head;
while (temp->seguinte != NULL)
{
temp = temp->seguinte;
}
temp->seguinte = newCliente;
}
}
fclose(fp);
}
return (head);
}


/////////// FIM DO LER OS FICHEIROS EM TXT/////////////////////////////////




// Determinar existência do 'codigo' na lista ligada 'inicio'
// devolve 1 se existir ou 0 caso contrário
int existeMeio(Meio *inicio, int cod)
{
  while (inicio != NULL)
  {
    if (inicio->codigo == cod)
      return (1);
    inicio = inicio->seguinte;
  }
  return (0);
}

// Remover um meio DA CONSOLA a partir do código
Meio* removerMeio(Meio* inicio, int cod) 
{
 Meio *anterior=inicio, *atual=inicio, *aux;

 if (atual==NULL) return(NULL); // lista ligada vazia
 else if (atual->codigo == cod) // remoção do 1º registo
 {aux = atual->seguinte;
  free(atual);
  return(aux);
 }
 else
 {while ((atual!=NULL)&&(atual->codigo!=cod)) 
  {anterior = atual;
   atual = atual->seguinte;
  }
  if (atual==NULL) return(inicio);
  else
  {anterior->seguinte = atual->seguinte;
   free(atual);
   return(inicio);
  }
 }
}
