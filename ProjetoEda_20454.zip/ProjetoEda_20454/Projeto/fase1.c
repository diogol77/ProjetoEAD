#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "meio.h"

//////////////////// Inserção de dados referentes a clientes///////////////
Cliente* inserirCliente(Cliente* inicio, int cod, char nome[], char morada[], float saldo) 
{
 Cliente *novo;
 novo = malloc(sizeof(struct cliente_registo));
 novo->codigo = cod;
 strcpy(novo->nome,nome);
 strcpy(novo->morada,morada);
 novo->saldo = saldo;
 novo->seguinte = inicio;
 return(novo);
}

/////////// Listar na consola os dados referentes aos clientes
void listarClientes(Cliente * inicio) {
    while (inicio != NULL) {
        printf("%d %s %s %.2f\n", inicio->codigo, inicio->nome, inicio->morada, inicio->saldo);
        inicio = inicio->seguinte;
    }
}


// Determinar existência do 'codigo' na lista ligada 'inicio'
// devolve 1 se existir ou 0 caso contrário
int existeCliente(Cliente* inicio, int cod)
{while(inicio!=NULL)
  {if (inicio->codigo == cod) return(1);
   inicio = inicio->seguinte;
  }
 return(0);
}

/////// Remover um cliente DA CONSOLA a partir do código
Cliente* removerCliente(Cliente* inicio, int cod) 
{
 Cliente *anterior=inicio, *atual=inicio, *aux;

 if (atual==NULL) return(NULL); // lista ligada vazia
 else if (atual->codigo == cod) // remoção do 1º registo
 {aux = atual->seguinte;
  free(atual);
  return(aux);
 }
 else
 {while ((atual!=NULL)&&(atual->codigo!=cod)) 
  {anterior = atual;
   atual = atual->seguinte;
  }
  if (atual==NULL) return(inicio);
  else
  {anterior->seguinte = atual->seguinte;
   free(atual);
   return(inicio);
  }
 }
}

// Inserção de dados referentes a gestores
Gestor* inserirGestor(Gestor* inicio, int cod, char nome[], char morada[]) 
{
 Gestor *novo;
 novo = malloc(sizeof(struct gestor_registo));
 novo->codigo = cod;
 strcpy(novo->nome,nome);
 strcpy(novo->morada,morada);
 novo->seguinte = inicio;
 return(novo);
}

// Listar na consola os dados referentes aos gestores
void listarGestores(Gestor * inicio)
{
  while (inicio != NULL)
  {
    printf("%d  %s %s\n",inicio->codigo,inicio->nome, inicio->morada);
    inicio = inicio->seguinte;
  }
}

// Determinar existência do 'codigo' na lista ligada 'inicio'
// devolve 1 se existir ou 0 caso contrário
int existeGestor(Gestor* inicio, int cod)
{while(inicio!=NULL)
  {if (inicio->codigo == cod) return(1);
   inicio = inicio->seguinte;
  }
 return(0);
}

// Remover um gestor a partir do código
Gestor* removerGestor(Gestor* inicio, int cod) 
{
 Gestor *anterior=inicio, *atual=inicio, *aux;

 if (atual==NULL) return(NULL); // lista ligada vazia
 else if (atual->codigo == cod) // remoção do 1º registo
 {aux = atual->seguinte;
  free(atual);
  return(aux);
 }
 else
 {while ((atual!=NULL)&&(atual->codigo!=cod)) 
  {anterior = atual;
   atual = atual->seguinte;
  }
  if (atual==NULL) return(inicio);
  else
  {anterior->seguinte = atual->seguinte;
   free(atual);
   return(inicio);
  }
 }
}

// Inserção de dados referentes a meio
 void inserirDadosMeio(Meio **meio) 
{
 int cod, cod_meio;
 char tipo[50];
 float bateria, autonomia;
 
 printf("Introduza o codigo do meio: ");
 scanf("%d", &cod_meio);
 if (!existeMeio(*meio, cod_meio))
 {
  printf("Introduza o tipo do meio: ");
  scanf(" %[^\n]", tipo);
  printf("Introduza a bateria do meio: ");
  scanf("%f", &bateria);
  printf("Introduza a autonomia do meio: ");
  scanf("%f", &autonomia);
  *meio = inserirMeio(*meio, cod_meio, tipo, bateria, autonomia);
 }

 
}
// Inserção de dados referentes a gestor
void inserirDadosGestor(Gestor **gestor) 
{
 int cod_gestor;
 char  nome[50], morada[50];
 printf("Introduza o codigo do gestor: ");
 scanf("%d", &cod_gestor);
 if (!existeGestor(*gestor, cod_gestor))
 {
  printf("Introduza o nome do gestor: ");
  scanf(" %[^\n]", &nome);
  printf("Introduza a morada do gestor: ");
  scanf(" %[^\n]", &morada);
  *gestor = inserirGestor(*gestor, cod_gestor, nome, morada);
 }
}
// Inserção de dados referentes a clientes 
void inserirDadosCliente(Cliente **cliente) 
{
 int  cod_cliente;
 char nome[50], morada[50];
 float saldo;

 printf("Introduza o codigo do cliente: ");
 scanf("%d", &cod_cliente);
 if (!existeCliente(*cliente, cod_cliente))
 {
  printf("Introduza o nome do cliente: ");
  scanf(" %[^\n]", &nome);
  printf("Introduza a morada do cliente: ");
  scanf(" %[^\n]", &morada);
  printf("Introduza o saldo do cliente: ");
  scanf("%f", &saldo);
  *cliente = inserirCliente(*cliente, cod_cliente, nome, morada, saldo);
 }
}

// Função que ordena os registos pela autonomia (DESC)
Meio* ordernarMeiosAutonomia(Meio* inicio) {
    if (inicio == NULL || inicio->seguinte == NULL) {
        // List is empty or has only one node, return as is
        return inicio;
    }

    Meio *p, *q, *r, *temp;
    int troca;

    do {
        troca = 0;
        p = NULL;
        q = inicio;
        r = q->seguinte;

        while (r != NULL) {
            if (q->autonomia < r->autonomia) {
                troca = 1;
                temp = r->seguinte;
                r->seguinte = q;
                q->seguinte = temp;

                if (p == NULL) {
                    inicio = r;
                } else {
                    p->seguinte = r;
                }

                p = r;
                r = q->seguinte;
            } else {
                p = q;
                q = r;
                r = r->seguinte;
            }
        }
    } while (troca);

    // Print the sorted list
    printf("\n");
    Meio* atual = inicio;
    while (atual != NULL) {
 
        atual = atual->seguinte;
    }

    return inicio;
}


//////Função principal
int main(){
 // Declaração de variáveis
 Meio *meio;
 Cliente *cliente;
 Gestor *gestor;
 int opcao, codigo, existe,cod;
char username[50], password[50]; //Dados do login (Só irá entrar se os dados forem username=gestor e password=gestor ou cliente, ou meio)

 // Inicialização de variáveis
 meio = NULL;
 cliente = NULL;
 gestor = NULL;

 // Apresentação do menu

  printf("Username: ");
    scanf("%s", username);

    printf("Password: ");
    scanf("%s", password);

    // Verificação de login
    if (strcmp(username, "meio") == 0 && strcmp(password, "meio") == 0) {
        printf("\n\nBem vindo ao sistema Aave.\nEscolha uma opcao :\n");
        //Inicio Menu
        do {
   meio = lerMeios();
    printf("\n\nBem vindo ao sistema.\nEscolha uma opcao :\n");
  printf("1 - Inserir dados sobre Meio.\n");
  printf("2 - Listar dados inseridos.\n");
  printf("3 - Remover dados.\n");
  printf("4 - Ordenar os meios pela autonomia.\n");
  printf("5 - Retorceder\n");

  scanf("%d", &opcao);

  switch (opcao)
  {
    case 1: inserirDadosMeio(&meio); 
    guardarMeios(meio);
    break;

   case 2:
	printf("\nMEIOS\n");
    
	listarMeios(meio);
	break;
   case 3:
	printf("\n > Insira o codigo do meio que deseja remover: ");
                                scanf("%d", &cod);
                                meio = removerMeio(meio, cod);
                                guardarMeios(meio);
	break;
   case 4:
	printf("\nMEIOS ORDENADOS POR AUTONOMIA\n");
	meio = ordernarMeiosAutonomia(meio);
       listarMeios(meio);

	break;
    case 5:
   system("cls");
 return main();
 break;

   default: printf("Opcao invalida.\n");
  }
 }while (opcao!=5);

}
 else if (strcmp(username, "gestor") == 0 && strcmp(password, "gestor") == 0) {
        printf("\n\nBem vindo ao sistema Aave.\nEscolha uma opcao :\n");
        //Inicio Menu
        do {
gestor=lerGestores();
    printf("\n\nBem vindo ao sistema.\nEscolha uma opcao :\n");
  printf("1 - Inserir dados sobre Gestores.\n");
  printf("2 - Listar dados inseridos.\n");
  printf("3 - Remover dados.\n");
  printf("4 - Retorceder\n");

  scanf("%d", &opcao);

  switch (opcao)
  {
    case 1: inserirDadosGestor(&gestor); 
    guardarGestor(gestor);
    break;
   case 2:
	printf("\nGestores\n"); 
	listarGestores(gestor);
	break;
   case 3:
	printf("\n > Insira o codigo do gestor que deseja remover: ");
                                scanf("%d", &cod);
                                gestor= removerGestor(gestor, cod);
                                guardarGestor(gestor);
	break;
    case 4:
     system("cls");
 return main();
 break;

   default: printf("Opcao invalida.\n");
  }
 }while (opcao!=4);
}
 else if (strcmp(username, "cliente") == 0 && strcmp(password, "cliente") == 0) {
        printf("\n\nBem vindo ao sistema \nEscolha uma opcao :\n");
        //Inicio Menu
        do {
cliente=lerClientes();
    printf("\n\nBem vindo ao sistema.\nEscolha uma opcao :\n");
  printf("1 - Inserir dados sobre Clientes.\n");
  printf("2 - Listar dados inseridos.\n");
  printf("3 - Remover dados.\n");
  printf("4 - Retorceder\n");

  scanf("%d", &opcao);

  switch (opcao)
  {
    case 1: inserirDadosCliente(&cliente); 
    guardarClientes(cliente);
    break;
   case 2:
	printf("\nClientes\n"); 
	listarClientes(cliente);
	break;
   case 3:
	printf("\n > Insira o codigo do meio que deseja remover: ");
                                scanf("%d", &cod);
                                cliente= removerCliente(cliente, cod);
                                guardarClientes(cliente);
	break;
    case 4:
      system("cls");
 return main();
break;

   default: printf("Opcao invalida.\n");
  }
 }while (opcao!=4);
}
}

